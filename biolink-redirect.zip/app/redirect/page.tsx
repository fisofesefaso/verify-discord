import { redirect } from "next/navigation"

export default async function RedirectPage() {
  // Replace with your actual biolink URL
  redirect("https://your-biolink-url.com")
}
